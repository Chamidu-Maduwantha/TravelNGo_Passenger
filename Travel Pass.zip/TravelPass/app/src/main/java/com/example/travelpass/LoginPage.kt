package com.example.travelpass

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import org.w3c.dom.Text

class LoginPage : AppCompatActivity() {
    lateinit var regButton: Button
    lateinit var edtNIC: Text
    lateinit var edtPassword: Text
    lateinit var btnLog : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        regButton = findViewById(R.id.regbtn)




        regButton.setOnClickListener {
            val intent = Intent(this,Register::class.java)
            startActivity(intent)
        }

    }
}